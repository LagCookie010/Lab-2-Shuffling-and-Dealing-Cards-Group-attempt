// Name: Darren Lagbao 
// Date: 10/2/2024
// Class: CS 145, Computer Science 2, Darrell Criss
// Lab: 2, Card Shuffling and Dealing Program
// Citation: W3 Schools, Darrell Criss's Lectures, 
// Purpose: A Card Game Program, using a 3 separate classes: Card, Manager, and Test Class.
// Using private modifier to securely store the Cards until a Accessor Method initializes it. 
// Class Purpose: Main is the class hosting the main game, using the Manager.java + CardDeck.java.
// classes to play a card Game.
// Notes:

public class Test {
    public static void main(String[] args) {
        Manager.Introduction(args);
    }

}// end of Test class
